package com.beaming.project.beam;
 
import java.util.Arrays;
import java.util.List;
 
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.Count;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.SimpleFunction;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;

/**
 * mvn compile exec:java -Dexec.mainClass=com.beaming.project.beam.WordCountPipeLine \
     -Dexec.args="--inputFile=words.txt --output=countsOut.txt" -Pdirect-runner


mvn compile exec:java -Dexec.mainClass=com.beaming.project.beam.WordCountPipeLine \
     -Dexec.args="--runner=DataflowRunner --project=silken-math-260320 \
                  --gcpTempLocation=gs://bucket_eliseo/tmp \
                  --inputFile=gs://bucket_eliseo/sp/* --output=gs://bucket_eliseo/counts" \
     -Pdataflow-runner

cd ~/beam/BeamTesting
cd ~/beam/BeamTesting/src/main/java/com/beaming/project/beam


mvn compile exec:java -Dexec.mainClass=com.beaming.project.beam.WordCountPipeLine \
     -Dexec.args= \
     -Pdataflow-runner
     
 cd ~/cloudPlatform/training-data-analyst/courses/data_analysis/lab2/javahelp/src/main/java/com/google/cloud/training/dataanalyst/javahelp    
 com.google.cloud.training.dataanalyst.javahelp 
 Grep.java  IsPopular.java  JavaProjectsThatNeedHelp.java  StreamDemoConsumer.java
 
 mvn compile exec:java -Dexec.mainClass=com.google.cloud.training.dataanalyst.javahelp.Grep \
     -Dexec.args= \
     -Pdataflow-runner
 
 
 eliseom17@cloudshell:~/cloudPlatform/training-data-analyst/courses/data_analysis/lab2 (silken-math-260320)$ ls
create_mvn.sh  javahelp  javahelp2  javahelp3  python
 
 mvn archetype:generate \
 -DarchetypeArtifactId=google-cloud-dataflow-java-archetypes-starter \
 -DarchetypeGroupId=com.google.cloud.dataflow \
 -DgroupId=com.google.cloud.training.dataanalyst.javahelp \
 -DartifactId=javahelp3 \
 -Dversion="[1.0.0,2.0.0]" \
 -DinteractiveMode=false \
  
    
    
    Run on cloud 
    cd ~/beam/BeamTesting
    mvn compile -e exec:java \
 -Dexec.mainClass=com.beaming.project.beam.WordCountPipeLine \
      -Dexec.args="--project=silken-math-260320 \
      --stagingLocation=gs://bucket_eliseo/staging/ \
      --tempLocation=gs://bucket_eliseo/staging/ \
      --runner=DataflowRunner"

 *
 */
public class WordCountPipeLine{
	
	 
	
	public static Pipeline createInitPipeline2( String[] args) {
		 PipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().create();
	      return Pipeline.create(options);
	}
	public static Pipeline createInitPipeline3( String[] args) {
		 PipelineOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().create();
	     return Pipeline.create(options);
	}
	
	
    public static void main( String[] args )    {
        System.out.println( "Starting jobs" );
       Pipeline pipeline = createInitPipeline3( args);
        
        //Read text from file
         PCollection<String> lines= pipeline.apply("Read from file", TextIO.read().from("words.txt"));
         
        //Split each line into words
        PCollection<List<String>> wordsPerLine = lines.apply("Groupying by word", MapElements.via( new SimpleFunction<String, List<String>>() {
        	 @Override
        	 public List<String> apply(String input){
//        		 return super.apply(input);
        		 return Arrays.asList(input.split(" "));
        	 }
		}));
        
       PCollection<String> words=  wordsPerLine.apply(Flatten.iterables());
         //Count number of words 
       PCollection<KV<String, Long>> wordCount= words.apply("Counting", Count.perElement());
         
       
       wordCount.apply(MapElements.via( new SimpleFunction<  KV<String, Long>, String>() {
    	   @Override
    	   public String apply(KV<String, Long> input) {
    		   System.out.println( "Retuning format" + String.format("%s => %s", input.getKey(), input.getValue()) );
    		   return String.format("%s => %s", input.getKey(), input.getValue());
    	   }
       }   )  ) 
       .apply("Saving" , TextIO.write().to("wordout.txt"))
       
       ;
       
        pipeline.run();
    }
}
